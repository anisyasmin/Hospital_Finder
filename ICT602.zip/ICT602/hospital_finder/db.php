<?php
$host = "localhost"; // For XAMPP, keep it as 'localhost'
$user = "root";      // Default XAMPP username
$pass = "";          // Default XAMPP password is empty
$db = "hospital_finder"; // Your database name

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
