<?php
header("Content-Type: application/json");
$conn = new mysqli("localhost", "root", "", "hospital_finder");

if ($conn->connect_error) {
    die(json_encode(["success" => false, "message" => "Database connection failed: " . $conn->connect_error]));
}

if (!isset($_GET['username'])) {
    die(json_encode(["success" => false, "message" => "Username is required"]));
}

$username = $_GET['username'];
$query = "SELECT first_name, last_name, state, district, latitude, longitude FROM users WHERE username = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $data = $result->fetch_assoc();

    // Debugging: Check if latitude and longitude exist
    if (is_null($data['latitude']) || is_null($data['longitude']) || $data['latitude'] == 0.0 || $data['longitude'] == 0.0) {
        echo json_encode(["success" => false, "message" => "Location data is missing or invalid"]);
    } else {
        echo json_encode(["success" => true, "data" => $data], JSON_PRETTY_PRINT);
    }
} else {
    echo json_encode(["success" => false, "message" => "User not found"]);
}

$stmt->close();
$conn->close();
?>
