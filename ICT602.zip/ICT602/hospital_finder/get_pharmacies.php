<?php
$host = "localhost";
$user = "root";
$password = "";
$dbname = "hospital_finder";

$conn = new mysqli($host, $user, $password, $dbname);

if ($conn->connect_error) {
    die(json_encode(["error" => "Database connection failed: " . $conn->connect_error]));
}

// Detect if the request is from Android (JSON) or Browser (HTML)
$isAndroidRequest = isset($_GET['json']) || 
                    (isset($_SERVER['HTTP_USER_AGENT']) && strpos($_SERVER['HTTP_USER_AGENT'], "okhttp") !== false);

// Fetch all pharmacies
$sql = "SELECT name, latitude, longitude FROM pharmacy";
$result = $conn->query($sql);

if ($isAndroidRequest) {
    // **Return JSON if request is from Android**
    header("Content-Type: application/json");
    $pharmacies = [];
    while ($row = $result->fetch_assoc()) {
        $pharmacies[] = $row;
    }
    echo json_encode($pharmacies, JSON_PRETTY_PRINT);
} else {
    // **Return HTML Table if accessed from a browser**
    echo "<html><head><title>Pharmacies List</title>";
    echo "<style>
            table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            th, td { border: 1px solid black; padding: 10px; text-align: center; }
            th { background-color: #007BFF; color: white; }
            tr:nth-child(even) { background-color: #f2f2f2; }
            body { font-family: Arial, sans-serif; margin: 20px; }
          </style>";
    echo "</head><body>";
    echo "<h2>Pharmacies List</h2>";
    echo "<table>";
    echo "<tr>
            <th>Name</th>
            <th>Latitude</th>
            <th>Longitude</th>
          </tr>";

    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row["name"]}</td>
                <td>{$row["latitude"]}</td>
                <td>{$row["longitude"]}</td>
              </tr>";
    }

    echo "</table>";
    echo "</body></html>";
}

$conn->close();
?>
