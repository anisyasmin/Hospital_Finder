<?php
$host = "localhost";
$user = "root";
$password = "";
$dbname = "hospital_finder";

$conn = new mysqli($host, $user, $password, $dbname);

if ($conn->connect_error) {
    die(json_encode(["error" => "Database connection failed: " . $conn->connect_error]));
}

// Detect if the request is from Android (JSON) or Browser (HTML)
$isAndroidRequest = isset($_GET['json']) || 
                    (isset($_SERVER['HTTP_USER_AGENT']) && strpos($_SERVER['HTTP_USER_AGENT'], "okhttp") !== false);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $district = $_POST['district'];
    $state = $_POST['state'];
    $symptoms = $_POST['symptoms'];
    $hospital_name = $_POST['hospital_name'];

    // 🔹 Fetch Latitude & Longitude from `hospitals` Table
    $lat = 0.00000000;
    $lon = 0.00000000;

    $stmt = $conn->prepare("SELECT latitude, longitude FROM hospitals WHERE name = ?");
    $stmt->bind_param("s", $hospital_name);
    $stmt->execute();
    $stmt->bind_result($lat, $lon);
    $stmt->fetch();
    $stmt->close();

    if ($lat == 0.00000000 && $lon == 0.00000000) {
        die(json_encode(["error" => "Hospital not found in database."]));
    }

    // 🔹 Insert Check-in Record with Correct Latitude & Longitude
    $stmt = $conn->prepare("INSERT INTO check_ins (firstname, lastname, district, state, latitude, longitude, symptoms, hospital_name) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssddss", $firstname, $lastname, $district, $state, $lat, $lon, $symptoms, $hospital_name);

    if ($stmt->execute()) {
        echo json_encode(["success" => "Check-in saved successfully"]);
    } else {
        echo json_encode(["error" => "Failed to save check-in: " . $stmt->error]);
    }
    $stmt->close();
}

// Fetch all check-ins
$sql = "SELECT checkin_id, firstname, lastname, district, state, latitude, longitude, checkin_time, symptoms, hospital_name FROM check_ins";
$result = $conn->query($sql);

if ($isAndroidRequest) {
    // **Return JSON if request is from Android**
    header("Content-Type: application/json");
    $data = [];

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $data[] = [
                "checkin_id" => $row["checkin_id"],
                "firstname" => $row["firstname"],
                "lastname" => $row["lastname"],
                "district" => $row["district"],
                "state" => $row["state"],
                "latitude" => $row["latitude"],
                "longitude" => $row["longitude"],
                "checkin_time" => $row["checkin_time"],
                "symptoms" => $row["symptoms"],
                "hospital_name" => $row["hospital_name"]
            ];
        }
    }
    echo json_encode($data, JSON_PRETTY_PRINT);
} else {
    // **Return HTML Table if accessed from a browser**
    echo "<html><head><title>Check-in Records</title>";
    echo "<style>
            table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            th, td { border: 1px solid black; padding: 10px; text-align: center; }
            th { background-color: #007BFF; color: white; }
            tr:nth-child(even) { background-color: #f2f2f2; }
            body { font-family: Arial, sans-serif; margin: 20px; }
          </style>";
    echo "</head><body>";
    echo "<h2>Check-in Records</h2>";
    echo "<table>";
    echo "<tr>
            <th>ID</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>District</th>
            <th>State</th>
            <th>Latitude</th>
            <th>Longitude</th>
            <th>Check-in Time</th>
            <th>Symptoms</th>
            <th>Hospital Name</th>
          </tr>";

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>{$row["checkin_id"]}</td>
                    <td>{$row["firstname"]}</td>
                    <td>{$row["lastname"]}</td>
                    <td>{$row["district"]}</td>
                    <td>{$row["state"]}</td>
                    <td>{$row["latitude"]}</td>
                    <td>{$row["longitude"]}</td>
                    <td>{$row["checkin_time"]}</td>
                    <td>{$row["symptoms"]}</td>
                    <td>{$row["hospital_name"]}</td>
                  </tr>";
        }
    } else {
        echo "<tr><td colspan='10'>No check-ins found</td></tr>";
    }
    echo "</table>";
    echo "</body></html>";
}

$conn->close();
?>
