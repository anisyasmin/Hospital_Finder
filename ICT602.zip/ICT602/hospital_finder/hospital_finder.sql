-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 31, 2025 at 08:47 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hospital_finder`
--

-- --------------------------------------------------------

--
-- Table structure for table `check_ins`
--

CREATE TABLE `check_ins` (
  `checkin_id` int(11) NOT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `district` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `latitude` decimal(10,8) NOT NULL,
  `longitude` decimal(11,8) NOT NULL,
  `checkin_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `symptoms` text DEFAULT NULL,
  `hospital_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `check_ins`
--

INSERT INTO `check_ins` (`checkin_id`, `firstname`, `lastname`, `district`, `state`, `latitude`, `longitude`, `checkin_time`, `symptoms`, `hospital_name`) VALUES
(1, 'Ain', 'Syuhada', 'Arau', 'Perlis', 6.44020000, 100.19500000, '2025-01-30 14:26:45', 'Cirit-birit', 'Hospital Tuanku Fauziah'),
(2, 'Anis', 'Yasmin', 'Arau', 'Perlis', 6.43310000, 100.26400000, '2025-01-30 14:32:00', 'Sakit Kepala', 'Klinik Kesihatan Arau'),
(3, 'Abdul', 'Rahman', 'Kangar', 'Perlis', 6.44380000, 100.19400000, '2025-01-30 14:35:22', 'Demam Panas', 'Hospital Kangar'),
(4, 'Mohd', 'Nabil', 'Arau', 'Perlis', 6.43310000, 100.26400000, '2025-01-30 14:35:22', 'Sakit Kepala', 'Klinik Kesihatan Arau'),
(5, 'Aizatul', 'Sufi', 'Arau', 'Perlis', 6.42870000, 100.26700000, '2025-01-30 14:35:22', 'Batuk Berpanjangan', 'Klinik 1Malaysia Arau'),
(6, 'Dania', 'Yucina', 'Kangar', 'Perlis', 6.43610000, 100.19100000, '2025-01-30 14:35:22', 'Sesak Nafas', 'Klinik Pakar Putra Kangar'),
(7, 'Aiman', 'Irsyad', 'Pauh', 'Perlis', 6.45650000, 100.24200000, '2025-01-30 14:35:22', 'Sakit Perut', 'Klinik Kesihatan Pauh'),
(8, 'Danial', 'Iman', 'Arau', 'Perlis', 6.43220000, 100.26500000, '2025-01-30 14:35:22', 'Alahan Kulit', 'Poliklinik Permai Arau'),
(9, 'Zizan', 'Razak', 'Arau', 'Perlis', 6.42820000, 100.26600000, '2025-01-30 14:41:43', 'Patah Kaki', 'Klinik Kita Arau'),
(10, 'Naim', 'Daniel', 'Arau', 'Perlis', 6.44380000, 100.19400000, '2025-01-30 16:07:32', 'Sakit Perut', 'Hospital Kangar'),
(12, 'Anis', 'Yasmin', 'Arau', 'Perlis', 6.44380000, 100.19400000, '2025-01-31 06:26:31', 'Sakit Perut', 'Hospital Kangar');

-- --------------------------------------------------------

--
-- Table structure for table `hospitals`
--

CREATE TABLE `hospitals` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `latitude` float NOT NULL,
  `longitude` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hospitals`
--

INSERT INTO `hospitals` (`id`, `name`, `latitude`, `longitude`) VALUES
(1, 'Hospital Tuanku Fauziah', 6.4402, 100.195),
(2, 'Hospital Kangar', 6.4438, 100.194),
(3, 'Klinik Kesihatan Arau', 6.4331, 100.264),
(4, 'Klinik 1Malaysia Arau', 6.4287, 100.267),
(5, 'Klinik Pakar Putra Kangar', 6.4361, 100.191),
(6, 'Klinik Kesihatan Pauh', 6.4565, 100.242),
(7, 'Poliklinik Permai Arau', 6.4322, 100.265),
(8, 'KPJ Perlis Specialist Hospital', 6.4478, 100.2),
(9, 'Klinik Kita Arau', 6.4282, 100.266),
(10, 'Klinik Kesihatan Simpang Empat', 6.417, 100.217);

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

CREATE TABLE `locations` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `latitude` float NOT NULL,
  `longitude` float NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pharmacy`
--

CREATE TABLE `pharmacy` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `latitude` decimal(10,6) NOT NULL,
  `longitude` decimal(10,6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pharmacy`
--

INSERT INTO `pharmacy` (`id`, `name`, `latitude`, `longitude`) VALUES
(1, 'Farmasi Arau', 6.432000, 100.261000),
(2, 'Farmasi Health Plus', 6.435000, 100.263000),
(3, 'Farmasi Kangar Best', 6.438100, 100.250000),
(4, 'Watsons Arau', 6.430500, 100.262000),
(5, 'Guardian Arau', 6.429800, 100.264000),
(6, 'Farmasi Sehat Sentiasa', 6.431200, 100.259000),
(7, 'Caring Pharmacy Arau', 6.428000, 100.265000),
(8, 'Big Pharmacy Kangar', 6.439500, 100.248000),
(9, 'Farmasi Perlis Jaya', 6.436800, 100.266000),
(10, 'Farmasi Medik Arau', 6.432500, 100.260000),
(11, 'Tigas Pharmacy Arau', 6.429100, 100.267000),
(12, 'Alpro Pharmacy Arau', 6.431900, 100.261000),
(13, 'Farmasi Mega Arau', 6.434400, 100.262000),
(14, 'Farmasi Sentral Arau', 6.433600, 100.264000),
(15, 'Farmasi Family Health', 6.437200, 100.265000);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `state` varchar(255) DEFAULT NULL,
  `district` varchar(255) DEFAULT NULL,
  `latitude` double DEFAULT NULL,
  `longitude` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `first_name`, `last_name`, `created_at`, `state`, `district`, `latitude`, `longitude`) VALUES
(3, 'putut@gmail.com', '$2y$10$NKdNS.14btCzOjjp6X7vuuhbOKcT2AVULVR3TKJBLgEpPnQJYX74O', 'Ahmad', 'Putut', '2025-01-28 13:09:35', 'Johor', 'Muar', 2.0442, 102.5689),
(4, 'aniya@gmail.com', '$2y$10$CrnJ/mPvCje3N7NefBd8.Ot0XhtZ6iU9aUmbHDILTSbNvZ2AkLp4C', 'Anis', 'Yasmin', '2025-01-28 13:14:41', 'Perlis', 'Arau', 6.4333, 100.2667),
(5, 'abu@gmail.com', '$2y$10$PbFVFU4H4dHZFHmxskXqJuc/3OVAOlraczoWD19DJ/xVYf4jgo/La', 'Abu', 'Bakar', '2025-01-28 19:39:08', 'Pahang', 'Kuantan', 3.8077, 103.326),
(6, 'abdul@gmail.com', '$2y$10$aKIOl4vSMqUVb1jBjlVnE.G3XH/kEdI3yXzwes/5SHygNhswwKmgK', 'Hasif', 'Irsyad', '2025-01-29 04:29:12', 'Selangor', 'Shah Alam', 3.08507, 101.53281),
(7, 'kamal@gmail.com', '$2y$10$98/CbttMTva584qrMdTRke2WGoQzV3gzeO7.BlB0Z0MxUT5ePrEu6', 'Kamal', 'Adli', '2025-01-29 15:18:18', 'Terengganu', 'Besut', 5.829012, 102.552378);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `check_ins`
--
ALTER TABLE `check_ins`
  ADD PRIMARY KEY (`checkin_id`);

--
-- Indexes for table `hospitals`
--
ALTER TABLE `hospitals`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `locations`
--
ALTER TABLE `locations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `pharmacy`
--
ALTER TABLE `pharmacy`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `check_ins`
--
ALTER TABLE `check_ins`
  MODIFY `checkin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `hospitals`
--
ALTER TABLE `hospitals`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `locations`
--
ALTER TABLE `locations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pharmacy`
--
ALTER TABLE `pharmacy`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `locations`
--
ALTER TABLE `locations`
  ADD CONSTRAINT `locations_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
