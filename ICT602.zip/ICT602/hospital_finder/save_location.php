<?php
header("Content-Type: application/json");
$conn = new mysqli("localhost", "root", "", "hospital_finder");

if ($conn->connect_error) {
    die(json_encode(["success" => false, "message" => "Database connection failed: " . $conn->connect_error]));
}

$username = $_POST['username'];
$state = $_POST['state'];
$district = $_POST['district'];

$query = "UPDATE users SET state=?, district=? WHERE username=?";
$stmt = $conn->prepare($query);
$stmt->bind_param("sss", $state, $district, $username);

if ($stmt->execute()) {
    echo json_encode(["success" => true, "message" => "Location Updated"]);
} else {
    echo json_encode(["success" => false, "message" => "SQL Error: " . $stmt->error]);
}

$conn->close();
?>
